"use client"

import React, { useEffect, useRef, useState } from "react"
import {
  Sun,
  Menu,
  X,
  MapPin,
  Users,
  FileText,
  TrendingUp,
  Shield,
  Clock,
  CheckCircle,
  AlertTriangle,
  Phone,
  Mail,
  MapIcon,
} from "lucide-react"

// Dynamically import the map component to avoid SSR issues
// const MapComponent = dynamic(() => import("./components/map-component"), {
//   ssr: false,
//   loading: () => <div className="map-loading">Loading Map...</div>,
// })

export default function HomePage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [activeStats, setActiveStats] = useState(0)
  const heroRef = useRef<HTMLDivElement>(null)

  const stats = [
    { label: "Total Complaints", value: "12,847", icon: FileText },
    { label: "Resolved Issues", value: "9,234", icon: TrendingUp },
    { label: "Active Users", value: "45,678", icon: Users },
    { label: "Response Time", value: "2.4 hrs", icon: MapPin },
  ]

  const features = [
    {
      icon: Shield,
      title: "Secure & Private",
      description: "Your complaints are handled with complete confidentiality and security.",
    },
    {
      icon: Clock,
      title: "24/7 Support",
      description: "Round-the-clock monitoring and response to urgent civic issues.",
    },
    {
      icon: CheckCircle,
      title: "Real-time Tracking",
      description: "Track your complaint status from submission to resolution.",
    },
    {
      icon: AlertTriangle,
      title: "Priority System",
      description: "Urgent issues are automatically prioritized for faster resolution.",
    },
  ]

  const services = [
    { title: "Water Supply Issues", count: "2,847", color: "#4ecdc4" },
    { title: "Road Maintenance", count: "1,923", color: "#45b7d1" },
    { title: "Garbage Collection", count: "3,156", color: "#f9ca24" },
    { title: "Street Lighting", count: "1,234", color: "#6c5ce7" },
    { title: "Traffic Management", count: "987", color: "#fd79a8" },
    { title: "Public Safety", count: "1,567", color: "#ff6b6b" },
  ]

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveStats((prev) => (prev + 1) % stats.length)
    }, 3000)
    return () => clearInterval(interval)
  }, [stats.length])

  useEffect(() => {
    // Smooth scroll behavior
    document.documentElement.style.scrollBehavior = "smooth"

    // Parallax effect
    const handleScroll = () => {
      if (heroRef.current) {
        const scrolled = window.pageYOffset
        heroRef.current.style.transform = `translateY(${scrolled * 0.3}px)`
      }
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
    setIsMenuOpen(false)
  }

  return (
    <div className="futuristic-portal">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 futuristic-nav">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <span className="futuristic-brand">
                <span className="brand-glow">CIVIC</span>
              </span>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                <button onClick={() => scrollToSection("home")} className="futuristic-link active">
                  HOME
                </button>
                <button onClick={() => scrollToSection("services")} className="futuristic-link">
                  Services
                </button>
                <button onClick={() => scrollToSection("features")} className="futuristic-link">
                  Features
                </button>
                <button onClick={() => scrollToSection("about")} className="futuristic-link">
                  About us
                </button>
                <button onClick={() => scrollToSection("contact")} className="futuristic-link">
                  Contact
                </button>
              </div>
            </div>

            <div className="hidden md:flex items-center space-x-3">
              <button className="futuristic-icon-btn">
                <Sun size={20} />
              </button>
              <button className="futuristic-primary-btn">DBIT 2025</button>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="futuristic-icon-btn">
                {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>

          {/* Mobile Navigation */}
          {isMenuOpen && (
            <div className="md:hidden">
              <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-black/90 backdrop-blur-lg rounded-lg mt-2">
                <button
                  onClick={() => scrollToSection("home")}
                  className="block futuristic-link active w-full text-left"
                >
                  HOME
                </button>
                <button onClick={() => scrollToSection("services")} className="block futuristic-link w-full text-left">
                  Services
                </button>
                <button onClick={() => scrollToSection("features")} className="block futuristic-link w-full text-left">
                  Features
                </button>
                <button onClick={() => scrollToSection("about")} className="block futuristic-link w-full text-left">
                  About us
                </button>
                <button onClick={() => scrollToSection("contact")} className="block futuristic-link w-full text-left">
                  Contact
                </button>
                <div className="flex items-center space-x-3 pt-4">
                  <button className="futuristic-icon-btn">
                    <Sun size={20} />
                  </button>
                  <button className="futuristic-primary-btn">DBIT 2025</button>
                </div>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="hero-section" id="home">
        <div className="hero-container">
          <div className="hero-content-wrapper">
            <div className="hero-content" ref={heroRef}>
              <div className="floating-particles"></div>

              <h1 className="hero-title">
                <span className="title-line">Civic Complaint</span>
                <span className="title-line">Portal</span>
              </h1>

              <p className="hero-subtitle">Advanced AI-powered complaint management system for smart cities</p>

              <div className="hero-buttons">
                <button className="futuristic-btn-primary">
                  <span>Login</span>
                  <div className="btn-glow"></div>
                </button>
                <button className="futuristic-btn-secondary">
                  <span>Map</span>
                  <div className="btn-glow"></div>
                </button>
                <button className="futuristic-btn-complaint">
                  <span>Register Complaint</span>
                  <div className="btn-glow"></div>
                  <div className="btn-pulse"></div>
                </button>
              </div>

              {/* Stats */}
              <div className="stats-container">
                <div className="stat-item active">
                  <div className="stat-icon">{React.createElement(stats[activeStats].icon, { size: 24 })}</div>
                  <div className="stat-content">
                    <div className="stat-value">{stats[activeStats].value}</div>
                    <div className="stat-label">{stats[activeStats].label}</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Background Effects */}
        <div className="hero-bg-effects">
          <div className="grid-overlay"></div>
          <div className="floating-orbs">
            <div className="orb orb-1"></div>
            <div className="orb orb-2"></div>
            <div className="orb orb-3"></div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="services-section" id="services">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center mb-16">
            <h2 className="section-title">Our Services</h2>
            <p className="section-subtitle">Comprehensive civic complaint management across all city departments</p>
          </div>

          <div className="services-grid">
            {services.map((service, index) => (
              <div
                key={index}
                className="service-card"
                style={{ "--accent-color": service.color } as React.CSSProperties}
              >
                <div className="service-icon" style={{ backgroundColor: service.color }}>
                  <FileText size={24} />
                </div>
                <h3 className="service-title">{service.title}</h3>
                <div className="service-count">{service.count}</div>
                <p className="service-description">Active complaints being processed</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="features-section" id="features">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center mb-16">
            <h2 className="section-title">Why Choose Our Platform</h2>
            <p className="section-subtitle">Advanced features designed for efficient civic complaint management</p>
          </div>

          <div className="features-grid">
            {features.map((feature, index) => (
              <div key={index} className="feature-card">
                <div className="feature-icon">{React.createElement(feature.icon, { size: 32 })}</div>
                <h3 className="feature-title">{feature.title}</h3>
                <p className="feature-description">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="about-section" id="about">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="about-content">
            <div className="about-text">
              <h2 className="section-title">About Our Platform</h2>
              <p className="about-description">
                Our Civic Complaint Portal is a cutting-edge solution designed to bridge the gap between citizens and
                local government. Using advanced AI and machine learning technologies, we ensure that every complaint is
                processed efficiently and transparently.
              </p>
              <p className="about-description">
                Since our launch in 2020, we have successfully processed over 50,000 complaints with an average
                resolution time of 2.4 hours. Our platform serves multiple cities and has become the gold standard for
                civic engagement.
              </p>
              <div className="about-stats">
                <div className="about-stat">
                  <div className="about-stat-number">50K+</div>
                  <div className="about-stat-label">Complaints Resolved</div>
                </div>
                <div className="about-stat">
                  <div className="about-stat-number">15</div>
                  <div className="about-stat-label">Cities Served</div>
                </div>
                <div className="about-stat">
                  <div className="about-stat-number">98%</div>
                  <div className="about-stat-label">Satisfaction Rate</div>
                </div>
              </div>
            </div>
            <div className="about-visual">
              <div className="about-card">
                <div className="about-card-content">
                  <h3>Mission Statement</h3>
                  <p>
                    To create transparent, efficient, and accessible civic services that empower citizens and improve
                    urban living.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="contact-section" id="contact">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center mb-16">
            <h2 className="section-title">Get In Touch</h2>
            <p className="section-subtitle">Have questions? We're here to help you navigate our platform</p>
          </div>

          <div className="contact-grid">
            <div className="contact-card">
              <div className="contact-icon">
                <Phone size={24} />
              </div>
              <h3 className="contact-title">Phone Support</h3>
              <p className="contact-info">+1 (555) 123-4567</p>
              <p className="contact-description">Available 24/7 for urgent issues</p>
            </div>

            <div className="contact-card">
              <div className="contact-icon">
                <Mail size={24} />
              </div>
              <h3 className="contact-title">Email Support</h3>
              <p className="contact-info">support@civicportal.gov</p>
              <p className="contact-description">Response within 2 hours</p>
            </div>

            <div className="contact-card">
              <div className="contact-icon">
                <MapIcon size={24} />
              </div>
              <h3 className="contact-title">Office Location</h3>
              <p className="contact-info">123 Government Plaza</p>
              <p className="contact-description">Open Mon-Fri, 9AM-5PM</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="footer-section">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="footer-content">
            <div className="footer-brand">
              <span className="futuristic-brand">
                <span className="brand-glow">CIVIC</span>
              </span>
              <p className="footer-description">Empowering citizens through technology and transparency.</p>
            </div>
            <div className="footer-links">
              <div className="footer-column">
                <h4 className="footer-title">Platform</h4>
                <ul className="footer-list">
                  <li>
                    <button onClick={() => scrollToSection("home")} className="footer-link">
                      Home
                    </button>
                  </li>
                  <li>
                    <button onClick={() => scrollToSection("services")} className="footer-link">
                      Services
                    </button>
                  </li>
                  <li>
                    <button onClick={() => scrollToSection("features")} className="footer-link">
                      Features
                    </button>
                  </li>
                </ul>
              </div>
              <div className="footer-column">
                <h4 className="footer-title">Support</h4>
                <ul className="footer-list">
                  <li>
                    <button onClick={() => scrollToSection("about")} className="footer-link">
                      About
                    </button>
                  </li>
                  <li>
                    <button onClick={() => scrollToSection("contact")} className="footer-link">
                      Contact
                    </button>
                  </li>
                  <li>
                    <a href="#" className="footer-link">
                      Help Center
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="footer-bottom">
            <p>&copy; 2025 Civic Complaint Portal. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
